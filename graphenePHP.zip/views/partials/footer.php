<h4 class="footer mt-5">
  Developed By
  <a rel="noopener" href="https://github.com/imradhe" target="_blank" style="text-decoration: none;">
    Radhe Shyam Salopanthula
  </a>
</h4>