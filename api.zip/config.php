<?php
$config = array(

        'APP_NAME'=>'GraphenePHP',
        'APP_MODE'=>'production', //production/testing
        'APP_TESTING_ROOT'=> null , //only while testing
        'APP_KEY'=>'',
        'APP_DEBUG'=>'true',
        'APP_URL'=>'http://graphene.kautilyaeducation.com/',


        'DB_CONNECTION'=>'mysql',
        'DB_HOST'=>'localhost',
        'DB_PORT'=>'3306',
        'DB_DATABASE'=>'kautilyaeducation',
        'DB_USERNAME'=>'ke',
        'DB_PASSWORD'=>'SriRadhe@123',

        'MAIL_DRIVER'=>'smtp',
        'MAIL_HOST'=>'smtp.mailtrap.io',
        'MAIL_PORT'=>'2525',
        'MAIL_USERNAME'=>'null',
        'MAIL_PASSWORD'=>'null',
        'MAIL_ENCRYPTION'=>'null'
);