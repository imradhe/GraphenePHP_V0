<?php
header('x-powered-by: none');
header('server-version: none');
header('x-xss-protection: true');
header('x-content-type-options: nosniff');