<div class="text-center footer">

            <a rel="noopener" href="https://kautilyaeducation.com" target="_blank" style="text-decoration: none;">
            <b>Sponsored By</b><br>
            <img src="<?php echo home();?>assets/img/KE.png" style="max-height: 60px;" alt="Kautilya Education" class="img-fluid mb-3 p-2">
          </a>
          </div>